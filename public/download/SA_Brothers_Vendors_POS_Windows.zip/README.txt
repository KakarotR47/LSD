SA BROTHERS VENDORS - POINT OF SALE (NATIVE WINDOWS APP)
============================================================

HOW TO RUN:
1. Double click 'SA_Brothers_Vendors_POS.exe'
2. The POS application will open directly in its own standalone desktop window.
3. No browser address bar, no command prompt required.

Enjoy using your SA Brothers Vendors POS software!
